create view USER_ST_GEOM_INDEX_V as
SELECT S.table_name,S.column_name,S.grid,S.srid,S.commit_int,S.version,S.status,S.index_name,S.uniqueness,S.distinct_keys,S.blevel,S.leaf_blocks,S.clustering_factor,S.density,S.num_rows,S.num_nulls,S.sample_size,S.last_analyzed,S.user_stats,S.st_funcs FROM SDE.ST_GEOMETRY_INDEX S WHERE S.OWNER IN (SELECT USER FROM DUAL)
/

