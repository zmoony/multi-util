create FUNCTION get_sequence(in_sequence varchar2)
    RETURN number
    IS
    next_val number;
BEGIN
    execute immediate 'SELECT ' || in_sequence || '.nextval FROM dual' INTO next_val;
    RETURN next_val;
EXCEPTION
    WHEN others THEN
        raise_application_error(SQLCODE, SQLERRM);
END;
/

