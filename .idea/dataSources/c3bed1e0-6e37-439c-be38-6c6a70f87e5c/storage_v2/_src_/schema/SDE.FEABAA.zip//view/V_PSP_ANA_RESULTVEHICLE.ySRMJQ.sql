create view V_PSP_ANA_RESULTVEHICLE as
select t.object_id,t.task_id,ts.task_name,t.info_kind,t.origin_picture_id,t.file_uri,t.has_plate,t.plate_class,pc.class_name as plate_class_name,
t.plate_color,pl.color_name as plate_color_name,t.plate_no,t.using_kind,uk.kind_name,t.vehicle_bigclass,vb.bigclass_name,t.vehicle_class,vc.class_name,t.vehicle_brand,br.brand_name,
t.vehicle_model,vm.model_name,t.vehicle_style,vs.style_name,t.vehicle_color,vo.color_name,t.pass_time,t.has_annual,t.annual_num,t.has_tissuebox,t.has_ornaments,
t.sunvisor_status,t.safetybelt_status,t.calling_status
from psp_ana_resultvehicle t
left join psp_ana_task ts on ts.task_id=t.task_id
left join psp_db_plateclass pc on pc.plate_class=t.plate_class
left join psp_db_platecolor pl on pl.plate_color=t.plate_color
left join psp_db_usingkind uk on uk.using_kind=t.using_kind
left join psp_db_vehiclebigclass vb on vb.vehicle_bigclass=t.vehicle_bigclass
left join psp_db_vehicleclass vc on vc.vehicle_class=t.vehicle_class
left join psp_db_vehiclebrand br on br.vehicle_brand=t.vehicle_brand
left join psp_db_vehiclemodel vm on vm.vehicle_model=t.vehicle_model
left join psp_db_vehiclestyle vs on vs.vehicle_style=t.vehicle_style
left join psp_db_vehiclecolor vo on vo.vehicle_color=t.vehicle_color
/

