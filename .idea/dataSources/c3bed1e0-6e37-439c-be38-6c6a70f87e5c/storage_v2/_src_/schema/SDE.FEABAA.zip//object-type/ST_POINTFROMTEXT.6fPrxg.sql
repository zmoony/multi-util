create Type st_pointfromtext 
                                                 
          under st_point
        --C_Type_Release 1001
(
  constructor Function st_pointfromtext(geom_str varchar2,srid number) Return self AS result deterministic,
  static Function get_release Return number
);
/

