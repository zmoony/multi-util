create procedure delete_PSP_DB_SURVEHICLE_p is --但路网数据更新停滞时定时更新路网拥堵等级
begin
  delete from PSP_DB_SURVEHICLE t where (t.record_state=0 and sysdate-t.cancel_time>45) or (sysdate-t.control_end_time>45);
  commit;
end;
/

