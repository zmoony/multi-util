create procedure alarm_vehicle_JOB is
  alarmId  NUMBER;

BEGIN
  --预警ID
  select ALARM_ID
  INTO alarmId
  from (
      select *
      from PSP_DB_ALARMVEHICLE
      order by dbms_random.value)
  where rownum=1;

  update PSP_DB_ALARMVEHICLE
  SET PASS_TIME=sysdate,ALARM_TIME=sysdate
  WHERE ALARM_ID=alarmId;

  COMMIT;
END;
/

