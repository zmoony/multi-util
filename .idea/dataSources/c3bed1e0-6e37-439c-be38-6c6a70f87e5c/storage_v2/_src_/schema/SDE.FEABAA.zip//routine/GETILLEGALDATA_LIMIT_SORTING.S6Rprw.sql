create PROCEDURE getIllegalData_limit_sorting(--违法分拣权限模式
       i_sorting_person in NUMBER,--分拣人
       i_begin_pass_days in number,--分拣开始有效期
       i_end_pass_days in number,--分拣结束有效期
       o_curcor_illegalData out SYS_REFCURSOR--返回数据，游标形式
)
as
begin_pass_days number :=15 ;  --分拣开始有效期,默认15天
end_pass_days number :=0 ;  --分拣结束有效期,默认0天
v_objectId NUMBER(15);--车辆违法ID
v_tollgateId VARCHAR2(64);--卡口id
v_tollgateName VARCHAR2(200);--卡口名称
v_captureType VARCHAR2(2);--违法采集设备类型
v_roadCode VARCHAR2(16);--道路代码
v_crossCode VARCHAR2(16);--路口路段代码
v_kilometers NUMBER(6);--公里数
v_meters NUMBER(6);--米数
v_roadName VARCHAR2(64);--道路名称
v_corssName VARCHAR2(64);--路口路段名称
v_roadKind NUMBER(2);--道路类型
begin
   if i_begin_pass_days is not null then begin_pass_days:=i_begin_pass_days; end if;
   if i_end_pass_days is not null then end_pass_days:=i_end_pass_days; end if;
   begin
    select object_id,TOLLGATE_ID,CAPTURE_TYPE into v_objectId,v_tollgateId,v_captureType from
      (
        select object_id,TOLLGATE_ID,CAPTURE_TYPE from psp_tr_illegal_event where SORTING_FLAG='3' and SORTING_PEOPLE=i_sorting_person
        and PASS_TIME>sysdate-begin_pass_days and PASS_TIME<sysdate-end_pass_days
      ) where rownum<2;
   exception
   when NO_DATA_FOUND then
     begin
       --首先查看卡口权限
       select object_id,TOLLGATE_ID,CAPTURE_TYPE into v_objectId,v_tollgateId,v_captureType from(
         select object_id,TOLLGATE_ID,CAPTURE_TYPE from (
           select object_id,PASS_TIME,TOLLGATE_ID,CAPTURE_TYPE from psp_tr_illegal_event ie
           where (SORTING_PEOPLE is null or SORTING_PEOPLE=i_sorting_person)
                 and data_status='1' and SORTING_FLAG='0' and PASS_TIME>sysdate-begin_pass_days and PASS_TIME<sysdate-end_pass_days
                 and tollgate_id in (select t3.tollgate_id
                      from PSP_TR_ILLEGAL_AUTHGROUP t1
                      left join PSP_TR_ILLEGAL_AUTHGROUPMEMBER t2
                        on t1.group_id=t2.group_id
                      left join PSP_TR_ILLEGAL_AUTHGROUPTOLL t3
                        on t1.group_id=t3.group_id
                     where t2.member_id=i_sorting_person and t1.group_type='0')
         )
       ) where rownum<2;
      exception
       when NO_DATA_FOUND then --卡口不存在查看违法类型权限
         begin
           select object_id,TOLLGATE_ID,CAPTURE_TYPE into v_objectId,v_tollgateId,v_captureType from(
             select object_id,TOLLGATE_ID,CAPTURE_TYPE from (
               select object_id,PASS_TIME,TOLLGATE_ID,CAPTURE_TYPE from psp_tr_illegal_event ie
               where (SORTING_PEOPLE is null or SORTING_PEOPLE=i_sorting_person)
                     and data_status='1' and SORTING_FLAG='0' and PASS_TIME>sysdate-begin_pass_days and PASS_TIME<sysdate-end_pass_days
                     and illegal_type in (select t3.ILLEGAL_TYPE
                          from PSP_TR_ILLEGAL_AUTHGROUP t1
                          left join PSP_TR_ILLEGAL_AUTHGROUPMEMBER t2
                            on t1.group_id=t2.group_id
                          left join PSP_TR_ILLEGAL_AUTHGROUPTYPE t3
                            on t1.group_id=t3.group_id
                         where t2.member_id=i_sorting_person and t1.group_type='0')
             )
           ) where rownum<2;
           exception
           when NO_DATA_FOUND then --违法类型也不存在的最后查看数据来源权限
             select object_id,TOLLGATE_ID,CAPTURE_TYPE into v_objectId,v_tollgateId,v_captureType from(
               select object_id,TOLLGATE_ID,CAPTURE_TYPE from (
                 select object_id,PASS_TIME,TOLLGATE_ID,CAPTURE_TYPE from psp_tr_illegal_event ie
                 where (SORTING_PEOPLE is null or SORTING_PEOPLE=i_sorting_person)
                       and data_status='1' and SORTING_FLAG='0' and PASS_TIME>sysdate-begin_pass_days and PASS_TIME<sysdate-end_pass_days
                       and data_record_source in (select t3.SOURCE_NO
                            from PSP_TR_ILLEGAL_AUTHGROUP t1
                            left join PSP_TR_ILLEGAL_AUTHGROUPMEMBER t2
                              on t1.group_id=t2.group_id
                            left join PSP_TR_ILLEGAL_AUTHGROUPSOURCE t3
                              on t1.group_id=t3.group_id
                           where t2.member_id=i_sorting_person and t1.group_type='0')
               )
             ) where rownum<2;
         end;
      end;
    update psp_tr_illegal_event set SORTING_FLAG=3,SORTING_PEOPLE=i_sorting_person where object_id=v_objectId;--将该条单据置为正在分拣，避免出现重复分拣
    commit;
   end;
   if v_captureType = '1' then
     begin
       select rc.ROAD_CODE,cc.cross_code,toll.kilometers,toll.meters,rc.ROAD_NAME,cc.CROSS_NAME,rc.ROAD_KIND into v_roadCode,v_crossCode,v_kilometers,v_meters,v_roadName,v_corssName,v_roadKind
          from PSP_DB_TOLLGATE toll
          LEFT JOIN PSP_TR_ROADCODE rc
            ON toll.ROAD_CODE = rc.ROAD_CODE
          LEFT JOIN PSP_TR_CROSSCODE cc
            ON toll.ROAD_CODE = cc.ROAD_CODE
           AND toll.CROSS_CODE = cc.CROSS_CODE
        where toll.tollgate_id = v_tollgateId;
      exception
       when NO_DATA_FOUND then
         select '','','','','','','' into v_roadCode,v_crossCode,v_kilometers,v_meters,v_roadName,v_corssName,v_roadKind from dual;
      end;
   end if;
   if v_captureType = '2' or v_captureType = '3' then
     begin
       select ie.ROAD_CODE,ie.cross_code,ie.kilometers,ie.meters,rc.ROAD_NAME,cc.CROSS_NAME,rc.ROAD_KIND into v_roadCode,v_crossCode,v_kilometers,v_meters,v_roadName,v_corssName,v_roadKind
          from psp_tr_illegal_event ie
          LEFT JOIN PSP_TR_ROADCODE rc
            ON ie.ROAD_CODE = rc.ROAD_CODE
          LEFT JOIN PSP_TR_CROSSCODE cc
            ON ie.ROAD_CODE = cc.ROAD_CODE
           AND ie.CROSS_CODE = cc.CROSS_CODE
        where ie.OBJECT_ID = v_objectId;
      exception
       when NO_DATA_FOUND then
         select '','','','','','','' into v_roadCode,v_crossCode,v_kilometers,v_meters,v_roadName,v_corssName,v_roadKind from dual;
      end;
   end if;
   begin
     if v_captureType = '1' then select TOLLGATE_NAME into v_tollgateName from PSP_DB_TOLLGATE where TOLLGATE_ID=v_tollgateId;
     elsif v_captureType = '2' then select CAMERA_NAME into v_tollgateName from PSP_DB_CAMERA where CAMERA_ID=v_tollgateId;
     elsif v_captureType = '3' then select DEVICE_NAME into v_tollgateName from PSP_TR_MOBILEDEVICE where DEVICE_NO=v_tollgateId;
     else v_tollgateName:='';
     end if;
   exception
   when NO_DATA_FOUND then
     v_tollgateName:='';
   end;
   open o_curcor_illegalData for
     SELECT OBJECT_ID,
            PLATE_NO,
            PLATE_CLASS,
            ILLEGAL_TYPE,
            PASS_TIME,
            TO_CHAR(PASS_TIME, 'yyyy-mm-dd hh24:mi:ss') AS PASS_TIME_STR,
            PASS_TIME2,
            TO_CHAR(PASS_TIME2, 'yyyy-mm-dd hh24:mi:ss') AS PASS_TIME_STR2,
            LANE_DIRECTION,
            TOLLGATE_ID,
            v_tollgateName as TOLLGATE_NAME,
            IMAGE_ONE,
            IMAGE_TWO,
            IMAGE_THREE,
            IMAGE_FOUR,
            IMAGE_FIVE,
            IMAGE_SIX,
            IMAGE_SEVEN,
            IMAGE_EIGHT,
            IMAGE_STORAGE,
            IMAGE_COUNT,
            SORTING_FLAG,
            LANE_NO,
            CAPTURE_TYPE,
            SORTING_INVALID_REASON,
            GATHER_WAY,
            AUDIT_FLAG,
            SORTING_PEOPLE,
            SORTING_REPEAT_PEOPLE,
            VEHICLE_SPEED,
            DECODE(CAPTURE_TYPE,
              '1',
              decode(DATA_RECORD_SOURCE,
                     3,
                     VEHICLE_STANDARD_SPEED,
                     (select MAX_SPEED
                        from psp_db_lane pdl
                       where pdl.LANE_NO = t.LANE_NO
                         and pdl.LANE_DIRECTION = t.LANE_DIRECTION
                         and pdl.TOLLGATE_ID = t.TOLLGATE_ID
                         and rownum = 1)),
              '') as VEHICLE_STANDARD_SPEED,
            VIDEO_ACCESS_STORAGE,
            DECODE(CAPTURE_TYPE,'1',v_roadCode,ROAD_CODE) ROAD_CODE,
            DECODE(CAPTURE_TYPE,'1',v_crossCode,CROSS_CODE) CROSS_CODE,
            DECODE(CAPTURE_TYPE,'1',v_kilometers,KILOMETERS) KILOMETERS,
            DECODE(CAPTURE_TYPE,'1',v_meters,METERS) METERS,
            DECODE(CAPTURE_TYPE,'1',v_roadName,'2',v_roadName,'3',v_roadName,null) ROAD_NAME,
            DECODE(CAPTURE_TYPE,'1',v_corssName,'2',v_corssName,'3',v_corssName,null) CROSS_NAME,
            DECODE(CAPTURE_TYPE,'1',v_roadKind,'2',v_roadKind,'3',v_roadKind,null) ROAD_KIND
        FROM PSP_TR_ILLEGAL_EVENT t
     where object_id=v_objectId;--根据ID查询违法数据，并返回
   return;
     exception
       when NO_DATA_FOUND then
         open o_curcor_illegalData for  select -1  as object_id from dual;
       return;
end;
/

