create Type     st_polygon 
                                               
        under SDE.st_surface 
        --C_Type_Release 1001
(
  constructor Function st_polygon(geom_str clob,srid number) Return self AS result deterministic,
  static Function get_release Return number
) NOT final;
/

