create trigger GDB_ITEM_TYP_TR
    after insert or update or delete
    on GDB_ITEMTYPES
DECLARE passed_table_name  VARCHAR2(32) := 'GDB_ITEMTYPES'; BEGIN UPDATE GDB_TABLES_LAST_MODIFIED SET last_modified_count = last_modified_count + 1 WHERE table_name = passed_table_name; IF SQL%NOTFOUND THEN INSERT INTO GDB_TABLES_LAST_MODIFIED VALUES (passed_table_name, 1);END IF; END;
/

