create view USER_ST_GEOMETRY_COLUMNS_V as
SELECT table_name,column_name,geometry_type,properties,srid FROM SDE.st_geometry_columns WHERE owner IN (SELECT USER FROM DUAL)
/

