create Type stgeom_aggr_convexhull AS OBJECT (cur_geom SDE.st_geometry, static function ODCIAggregateInitialize (sctx IN OUT stgeom_aggr_convexhull) return number,member function ODCIAggregateIterate (self IN OUT stgeom_aggr_convexhull, value IN SDE.st_geometry) return number,member function ODCIAggregateTerminate (self IN stgeom_aggr_convexhull, returngeom OUT SDE.st_geometry,flags IN number) return number,member function ODCIAggregateMerge (self IN OUT stgeom_aggr_convexhull,ctx2 IN stgeom_aggr_convexhull) return number);
/

