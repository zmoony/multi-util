create trigger PSP_TR_ILLEGAL_RESPORT_TRI_LY
    before insert
    on PSP_TR_ILLEGAL_RESPORT
    for each row
declare v_dataRecordSource varchar2(2);
begin
    select data_record_source into v_dataRecordSource from psp_tr_illegal_event illegal where illegal.object_id = :new.illegal_id;
    if '2'=v_dataRecordSource then
        begin
    declare CURSOR curRoute IS select DISTINCT toll.ROUTE_ID from PSP_TR_PASSTOLLGATE toll where toll.TOLLGATE_ID=:new.TOLLGATE_ID;
    route_device_no varchar2(32);
      begin
        for curRouteIn in curRoute loop
          select t.DEVICE_NO into route_device_no from PSP_TR_ILLEGAL_ROUTEREPORT_LY t where t.route_id=curRouteIn.route_id;
          if  route_device_no is not null then
            :new.device_no := route_device_no;
            EXIT;
          end if;
        end loop;
      end;
    end;
    end if;
end;
/

