create procedure illegal_event_JOB is
objectId  NUMBER;
objectId2  NUMBER;
objectId3  NUMBER;
objectId4  NUMBER;
objectId5 NUMBER;

BEGIN
     --ID
  select OBJECT_ID
  INTO objectId
  from (
      select *
      from PSP_TR_ILLEGAL_EVENT
      order by dbms_random.value)
  where rownum=1;

      --ID
  select OBJECT_ID
  INTO objectId2
  from (
      select *
      from PSP_TR_ILLEGAL_EVENT
      order by dbms_random.value)
  where rownum=1;

          --ID
  select OBJECT_ID
  INTO objectId3
  from (
      select *
      from PSP_TR_ILLEGAL_EVENT
      order by dbms_random.value)
  where rownum=1;

          --ID
  select OBJECT_ID
  INTO objectId4
  from (
      select *
      from PSP_TR_ILLEGAL_EVENT
      order by dbms_random.value)
  where rownum=1;

          --ID
  select OBJECT_ID
  INTO objectId5
  from (
      select *
      from PSP_TR_ILLEGAL_EVENT
      order by dbms_random.value)
  where rownum=1;

  update PSP_TR_ILLEGAL_EVENT
  SET PASS_TIME=sysdate
  WHERE OBJECT_ID=objectId or OBJECT_ID=objectId2  or OBJECT_ID=objectId3  or OBJECT_ID=objectId4  or OBJECT_ID=objectId5;
  COMMIT;
END;
/

