create view GDB_ITEMS_VW as
select objectid,uuid,type,name,physicalname,path,url,properties, defaults,datasetsubtype1,datasetsubtype2,datasetinfo1,datasetinfo2, sde.sdexmltotext(d1.xml_doc) as definition, sde.sdexmltotext(d2.xml_doc) as documentation, sde.sdexmltotext(d3.xml_doc) as iteminfo, shape FROM GDB_ITEMS LEFT OUTER JOIN sde_xml_doc1 d1 on gdb_items.definition = d1.sde_xml_id LEFT OUTER JOIN sde_xml_doc2 d2 on gdb_items.documentation = d2.sde_xml_id LEFT OUTER JOIN sde_xml_doc3 d3 on gdb_items.iteminfo = d3.sde_xml_id
/

