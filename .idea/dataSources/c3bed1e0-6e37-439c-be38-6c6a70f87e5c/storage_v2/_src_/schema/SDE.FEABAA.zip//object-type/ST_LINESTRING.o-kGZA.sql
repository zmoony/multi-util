create Type     st_linestring 
                                              
        under SDE.st_curve 
        --C_Type_Release 1001
(
  constructor Function st_linestring(geom_str clob,srid number) Return self AS result deterministic,
  static Function get_release Return number
) NOT final;
/

