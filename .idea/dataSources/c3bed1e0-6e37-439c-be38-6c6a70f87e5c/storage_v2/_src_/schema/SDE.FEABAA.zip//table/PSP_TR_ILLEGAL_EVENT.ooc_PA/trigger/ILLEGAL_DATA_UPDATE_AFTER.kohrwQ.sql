create trigger ILLEGAL_DATA_UPDATE_AFTER
    after update
    on PSP_TR_ILLEGAL_EVENT
    for each row
declare
  PRAGMA AUTONOMOUS_TRANSACTION;
begin
  if (:new.SORTING_INVALID_REASON=2 and :new.SORTING_FLAG=2 and (:old.sorting_flag!=:new.SORTING_FLAG or :new.SORTING_INVALID_REASON!=:old.SORTING_INVALID_REASON)) 
    or (:new.AUDIT_INVALID_REASON=2 and :new.AUDIT_FLAG=2 and (:old.AUDIT_FLAG!=:new.AUDIT_FLAG or :new.AUDIT_INVALID_REASON!=:old.AUDIT_INVALID_REASON)) then
    insert into PSP_TR_ILLEGALNOTE
      (ID, TYPE, PLATE_NO, PLATE_CLASS, STATE, ILLEGAL_ID, SEND_TYPE)
      select sys_guid, 1, :new.plate_no, :new.plate_class, 1,t.object_id, 1
        from psp_tr_illegal_event t
       where t.object_id=:new.object_id;
  end if;
  commit;
end;
/

