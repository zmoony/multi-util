create procedure closeSortingAndAudit is
begin
  update PSP_TR_ILLEGAL_SOURCE set PROCESS = 0;
  update psp_tr_illegal_event t
     set sorting_flag = 99, audit_flag = 99, sorting_audit = 1
   where t.DATA_STATUS = '1'
     and (nvl(t.sorting_flag, 0) = 0 or t.sorting_flag = 1 or
         t.sorting_flag = 3)
     and (nvl(t.audit_flag, 0) = 0 or t.audit_flag = 3)
     and to_char(t.pass_time, 'YYYY-MM-DD') =
         to_char(sysdate, 'YYYY-MM-DD');
end;
/

