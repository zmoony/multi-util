create Type     st_multipolygon 
                                               
        under SDE.st_multisurface 
        --C_Type_Release 1001
(
  constructor Function st_multipolygon(geom_str clob,srid number) Return self AS result deterministic,
    static Function get_release Return number
) ;
/

