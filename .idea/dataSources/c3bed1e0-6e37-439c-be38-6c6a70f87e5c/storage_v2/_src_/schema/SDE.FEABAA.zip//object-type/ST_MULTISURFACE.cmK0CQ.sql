create Type     st_multisurface 
                                              
        under SDE.st_geomcollection 
        --C_Type_Release 1001
(
  constructor Function st_multisurface(geom_str clob,srid number) Return self AS result deterministic,
  static Function get_release Return number
) NOT final;
/

