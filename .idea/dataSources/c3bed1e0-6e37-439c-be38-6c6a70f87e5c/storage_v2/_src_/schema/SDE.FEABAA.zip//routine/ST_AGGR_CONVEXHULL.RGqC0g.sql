create FUNCTION st_aggr_convexhull (input SDE.st_geometry) return SDE.st_geometry AGGREGATE USING stgeom_aggr_convexhull;
/

