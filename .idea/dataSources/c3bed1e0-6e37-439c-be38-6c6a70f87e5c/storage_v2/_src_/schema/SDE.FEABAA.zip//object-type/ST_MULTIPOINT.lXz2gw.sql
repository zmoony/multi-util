create Type     st_multipoint 
                                               
        under SDE.st_geomcollection 
        --C_Type_Release 1001
(
  constructor Function st_multipoint(geom_str clob,srid number) Return self AS result deterministic,
  static Function get_release Return number
);
/

