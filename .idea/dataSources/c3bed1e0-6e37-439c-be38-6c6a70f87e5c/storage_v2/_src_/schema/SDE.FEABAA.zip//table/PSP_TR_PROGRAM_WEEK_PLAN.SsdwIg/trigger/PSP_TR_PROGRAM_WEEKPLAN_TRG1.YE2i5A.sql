create trigger PSP_TR_PROGRAM_WEEKPLAN_TRG1
    before insert
    on PSP_TR_PROGRAM_WEEK_PLAN
    for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

