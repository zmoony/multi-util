create procedure signal_cross_JOB is
  crossId  NUMBER;

BEGIN
  --信号机ID
  select CROSS_ID
  INTO crossId
  from (
      select *
      from PSP_TR_SIGNALCROSS
      order by dbms_random.value)
  where rownum=1;

  update PSP_TR_SIGNALCROSS
  SET UPDATE_TIME=sysdate
  WHERE CROSS_ID=crossId;
  COMMIT;
END;
/

