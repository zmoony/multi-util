create Type Body st_pointfromtext AS

constructor Function st_pointfromtext(geom_str varchar2,srid number) 
    Return self AS result
 IS
   temp          varchar2(1);
   tempraw       raw(1);
   entity        number;
   geom_type     number;
   name          varchar2(32);
   spref_r       SDE.spx_util.spatial_ref_record_t;
   shape         SDE.st_geom_util.shape_r;
   is_empty      boolean := False;
   rc            number;
   buffer        clob;
  
 Begin
  
   geom_type := SDE.st_geom_util.unspecified_type; 
   buffer := geom_str;
   SDE.st_geom_util.get_type(buffer,entity,geom_type,is_empty,SDE.st_geom_util.point_type);
 
   If entity = SDE.st_geom_util.sg_illegal_shape THEN
     raise_application_error (SDE.st_type_util.st_geometry_invalid_type,'ST_GEOMETRY type must be a ST_POINT type.');
   End If;
   
   SDE.st_geom_util.get_name(entity,name);

   If name != 'POINT' THEN
     raise_application_error (SDE.st_type_util.st_geometry_invalid_type,'ST_GEOMETRY type must be a ST_POINT type.');
   End If;
   
   spref_r.srid := srid;
   rc := SDE.st_spref_util.select_spref(spref_r);
   If rc != SDE.st_type_user.se_success THEN
		  raise_application_error (SDE.st_type_util.st_no_srid,'SRID '||spref_r.srid||
		                           ' does not exist in ST_SPATIAL_REFERENCES table.');
   End If;
		
   shape.points := empty_blob();
   shape.numpts := 0;
   shape.entity := 0;
   shape.minx   := 0;
   shape.miny   := 0;
   shape.maxx   := 0;
   shape.maxy   := 0;
   shape.area   := 0;
   shape.len    := 0;
   shape.minz   := NULL;
   shape. maxz  := NULL;
   shape.minm   := NULL;
   shape.maxm   := NULL;
   
   temp := lpad('a', 1, 'a');
   tempraw := utl_raw.cast_to_raw (temp);
   shape.points := tempraw;
   
   If is_empty = False THEN
     SDE.st_geometry_shapelib_pkg.geometryfromtext(buffer,spref_r.srid,spref_r.x_offset,spref_r.y_offset,spref_r.xyunits,
                                                   spref_r.z_offset,spref_r.z_scale,spref_r.m_offset,spref_r.m_scale,
									               spref_r.Definition,geom_type,shape.numpts,shape.entity,shape.minx,shape.miny,
									               shape.maxx,shape.maxy,shape.minz,shape.maxz,shape.minm,shape.maxm,
												   shape.area,shape.len,shape.points);
   ELSE
     shape.numpts := 0;
     If geom_type > SDE.st_geom_util.unspecified_type Then
       shape.entity := geom_type;
     else
       shape.entity := 0;
     end if;      
     shape.minx   := 0;
     shape.miny   := 0;
     shape.maxx   := 0;
     shape.maxy   := 0;
	 shape.minz   := NULL;
	 shape.maxz   := NULL;
	 shape.minm   := NULL;
	 shape.maxm   := NULL;
     shape.area   := 0;
     shape.len    := 0;
     shape.points := empty_blob();
     shape.srid   := srid;
   End If;
  
   if(shape.numpts IS NULL and shape.entity = 0) then
     self.entity    := shape.entity;
     self.numpts    := 0;
     self.minx      := 0;
     self.maxx      := 0;
     self.miny      := 0;
     self.maxy      := 0;
     self.minz      := NULL;
     self.maxz      := NULL;
     self.minm      := NULL;
     self.maxm      := NULL;
     self.srid      := srid;
   else
     self.entity   := shape.entity;
     self.numpts   := shape.numpts;
     self.minx     := shape.minx;
     self.miny     := shape.miny;
     self.maxx     := shape.maxx;
     self.maxy     := shape.maxy;
   
     if(shape.minz IS NULL) then
       self.minz := NULL;
     else
       self.minz := shape.minz;
     end if;
     
     if(shape.maxz IS NULL) then
       self.maxz := NULL;
     else
       self.maxz := shape.maxz;
     end if;
  
     if(shape.minm IS NULL) then
       self.minm := NULL;
     else
       self.minm := shape.minm;
     end if;
     
     if(shape.maxm IS NULL) then
       self.maxm := NULL;
     else
       self.maxm := shape.maxm;
     end if;
     
   end if;
   
   self.area     := 0;
   self.len      := 0;
   self.srid     := srid;
   self.points   := shape.points;
   
   Return;
End st_pointfromtext;

static Function get_release
  Return number
  IS
    c_type_release    Constant pls_integer := 1007;
	
  Begin
    Return c_type_release;
  End get_release;
 End;
/

