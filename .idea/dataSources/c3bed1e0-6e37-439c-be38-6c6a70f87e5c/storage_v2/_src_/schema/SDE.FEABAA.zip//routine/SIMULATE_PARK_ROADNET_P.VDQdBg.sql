create procedure simulate_park_roadNet_p is --模拟停车场和路网拥堵等级变化
begin
  update PSP_TR_PARKINGLOT set PARKINGLOT_NUMREST=floor(dbms_random.value(PARKINGLOT_NUMTOTAL,PARKINGLOT_NUMTOTAL - 10));
  update PSP_TR_ORDINARYROAD set CONGESTION_LEVEL=floor(dbms_random.value(1,5));
  update PSP_TR_PRIMARYROAD set CONGESTION_LEVEL=floor(dbms_random.value(1,5));
  update PSP_TR_SECONDARYROAD set CONGESTION_LEVEL=floor(dbms_random.value(1,5));
  update PSP_TR_SIMPLEROAD set CONGESTION_LEVEL=floor(dbms_random.value(1,5));
  commit;
end;
/

