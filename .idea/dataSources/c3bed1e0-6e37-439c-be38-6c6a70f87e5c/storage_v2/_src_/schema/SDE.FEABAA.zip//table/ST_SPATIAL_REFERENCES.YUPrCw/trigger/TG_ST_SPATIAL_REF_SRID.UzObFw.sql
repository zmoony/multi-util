create trigger TG_ST_SPATIAL_REF_SRID
    before insert or update of SRID
    on ST_SPATIAL_REFERENCES
    for each row
DECLARE CURSOR select_seq IS SELECT ST_SPREF_SEQ.nextval FROM dual; SEQ_O         NUMBER; INVALID_SEQ   EXCEPTION; BEGIN IF INSERTING THEN OPEN select_seq; FETCH select_seq INTO SEQ_O; IF select_seq%NOTFOUND THEN RAISE INVALID_SEQ; ELSE CLOSE select_seq; END IF; :NEW.SRID := SEQ_O; END IF; EXCEPTION WHEN INVALID_SEQ THEN raise_application_error (-20201,'ST_SPATIAL_REFERENCES sequence ST_SPREF_SEQ not found.'); CLOSE select_seq; END;
/

