create view GDB_ITEMRELATIONSHIPS_VW as
SELECT objectid,uuid,type,originid,destid,properties, sde.sdexmltotext(d1.xml_doc) as attributes FROM GDB_ItemRelationships LEFT OUTER JOIN sde_xml_doc4 d1 on GDB_ItemRelationships.attributes = d1.sde_xml_id
/

