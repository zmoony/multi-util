create procedure TR_CONGESTION_MINUTELEVEL_JOB is
  direction  NUMBER;
  minute     NUMBER(2);
  congestion NUMBER;
  avgSpeed   NUMBER;
  jamratio   NUMBER;
  roadCode VARCHAR(64);
  AreaCode VARCHAR(64);
  HotAreaCode VARCHAR(64);
BEGIN
  --生成1~4随机数
  select trunc(dbms_random.value(1, 4)) into direction from dual;
  --分钟(每两分钟)
  select time
    into minute
    from (select CASE         
         WHEN SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) > 0 and SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) <= 2 THEN
          to_number(SUBSTR(TO_CHAR(sysdate, 'mi'), 1, 1) || 2) 
         WHEN SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) > 2 and SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) <= 4 THEN
          to_number(SUBSTR(TO_CHAR(sysdate, 'mi'), 1, 1) || 4) 
         WHEN SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) > 4 and SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) <= 6 THEN
          to_number(SUBSTR(TO_CHAR(sysdate, 'mi'), 1, 1) || 6) 
         WHEN SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) > 6 and SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) <= 8 THEN
          to_number(SUBSTR(TO_CHAR(sysdate, 'mi'), 1, 1) || 8) 
         WHEN SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) > 8 and SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) < 10 THEN
          to_number(SUBSTR(TO_CHAR(sysdate, 'mi'), 1, 1)+1 || 0)
         WHEN SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) = 0 THEN
          to_number(SUBSTR(TO_CHAR(sysdate, 'mi'), 1, 1) || 0)
       END AS time
  from dual);
  --拥堵系数
  select ROUND(dbms_random.value(1, 10),2) into congestion from dual;
  --平均速度
  select ROUND(dbms_random.value(5, 50),2) into avgSpeed from dual;
  --拥堵里程占比
  select ROUND(dbms_random.value(10, 30),2) into jamratio from dual;
  
  select decode(trunc(dbms_random.value(0,6)),0,10002,1,10003,2,10005,3,10004,4,10006,5,10002,6,10007) into roadCode from dual;
  select decode(trunc(dbms_random.value(0,3)),0,320115021,1,320115022,2,320115023,3,320115024) into AreaCode from dual;
  select 1 into HotAreaCode from dual;
  
--roadCode
INSERT INTO PSP_TR_CONGESTION_MINUTELEVEL
  (id,
   ROAD_CODE,
   --Area_Code,
   --Hot_Area_Code,
   --All_Road,
   Year,
   Direction,
   Month,
   Day,
   Hour,
   Minute,
   Congestion,
   RKSJ,
   Tjsj,
   AVG_SPEED,
   JAMRATIO)
VALUES
  (sys_guid(),
   roadCode,
   --'',
   --'',
   --'',
   to_char(sysdate, 'yyyy'),
   direction,
   to_char(sysdate, 'MM'),
   to_char(sysdate, 'DD'),
   to_char(sysdate, 'HH24'),
   minute,
   congestion,
   sysdate,
   sysdate,
   avgSpeed,
   jamratio);
 
--AreaCode
INSERT INTO PSP_TR_CONGESTION_MINUTELEVEL
  (id,
   Area_Code,
   Year,
   Direction,
   Month,
   Day,
   Hour,
   Minute,
   Congestion,
   RKSJ,
   Tjsj,
   AVG_SPEED,
   JAMRATIO)
VALUES
  (sys_guid(),
   AreaCode,
   to_char(sysdate, 'yyyy'),
   direction,
   to_char(sysdate, 'MM'),
   to_char(sysdate, 'DD'),
   to_char(sysdate, 'HH24'),
   minute,
   congestion,
   sysdate,
   sysdate,
   avgSpeed,
   jamratio);

--AreaCode
INSERT INTO PSP_TR_CONGESTION_MINUTELEVEL
  (id,
   Hot_Area_Code,
   Year,
   Direction,
   Month,
   Day,
   Hour,
   Minute,
   Congestion,
   RKSJ,
   Tjsj,
   AVG_SPEED,
   JAMRATIO)
VALUES
  (sys_guid(),
   HotAreaCode,
   to_char(sysdate, 'yyyy'),
   direction,
   to_char(sysdate, 'MM'),
   to_char(sysdate, 'DD'),
   to_char(sysdate, 'HH24'),
   minute,
   congestion,
   sysdate,
   sysdate,
   avgSpeed,
   jamratio); 

--AreaCode
INSERT INTO PSP_TR_CONGESTION_MINUTELEVEL
  (id,
   All_Road,
   Year,
   Direction,
   Month,
   Day,
   Hour,
   Minute,
   Congestion,
   RKSJ,
   Tjsj,
   AVG_SPEED,
   JAMRATIO)
VALUES
  (sys_guid(),
   'all',
   to_char(sysdate, 'yyyy'),
   direction,
   to_char(sysdate, 'MM'),
   to_char(sysdate, 'DD'),
   to_char(sysdate, 'HH24'),
   minute,
   congestion,
   sysdate,
   sysdate,
   avgSpeed,
   jamratio); 
  COMMIT;
END;
/

