create trigger TG_SPATIAL_REF_AUTH_SRID
    before update of AUTH_SRID
    on SPATIAL_REFERENCES
    for each row
BEGIN IF :old.AUTH_SRID IS NOT NULL AND :old.auth_srid <> :new.auth_srid THEN RAISE_APPLICATION_ERROR(-20085, 'Invalid SDE.SPATIAL_REFERENCES update. The update attempted to change the AUTH_SRID.'); END IF; END;
/

