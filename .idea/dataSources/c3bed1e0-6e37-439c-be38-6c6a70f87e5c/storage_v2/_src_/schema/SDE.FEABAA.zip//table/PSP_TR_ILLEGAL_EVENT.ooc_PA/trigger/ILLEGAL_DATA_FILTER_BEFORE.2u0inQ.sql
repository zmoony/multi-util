create trigger ILLEGAL_DATA_FILTER_BEFORE
    before insert
    on PSP_TR_ILLEGAL_EVENT
    for each row
declare
  v_count NUMBER(1);
  v_process NUMBER(2);
  v_tollgateId VARCHAR2(64);
  v_timeQuantum VARCHAR2(400);
  v_tollgateId2 VARCHAR2(64);
  v_tollgateId3 VARCHAR2(64);
  Cursor match_filter_cursor is
    select distinct t1.policy_id, t1.run_mode
      from psp_tr_illegal_filterpolicy t1
      left join PSP_TR_ILLEGAL_FILTERLANE t2
        on t1.policy_id=t2.policy_id
     where t1.policy_state=1
       and t1.approval_state=1
       and t2.tollgate_id=:new.tollgate_id
       and (t2.lane_direction=:new.lane_direction or t2.lane_direction is null)
       and (t2.lane_no=:new.lane_no or t2.lane_no is null)
       and t1.start_time<=:new.pass_time
       and (t1.end_time>=:new.pass_time or t1.end_time is null)
       and (t1.illegal_type = :new.illegal_type or
           t1.illegal_type like '%' || ',' || :new.illegal_type ||'%' or
           t1.illegal_type like '%' || :new.illegal_type || ',' ||'%');
begin
  --检查接入的点位是否在平台中存在
  if :new.CAPTURE_TYPE=1 then
    begin
      select t.tollgate_id into v_tollgateId3 from psp_db_tollgate t where t.tollgate_id=:new.tollgate_id;
      if v_tollgateId3 is not null and :new.data_status is null then
        :new.data_status:=1;
      end if;
    exception
    when NO_DATA_FOUND then
      :new.data_status:=0;
    end;
  end if;
  if :new.data_status=1 then
    --根据策略配置检查数据是否有效
    for item in match_filter_cursor loop
      if item.run_mode=0 then --模式1
        :new.data_status:=0;
        exit;
      elsif item.run_mode=1 then -- 模式2，检查时段
        select count(*) into v_count from psp_tr_illegal_filterquantum t
        where to_date(t.begin_time,'hh24:mi:ss')<=to_date(to_char(:new.pass_time, 'hh24:mi:ss'),'hh24:mi:ss')
          and to_date(t.end_time,'hh24:mi:ss')>=to_date(to_char(:new.pass_time, 'hh24:mi:ss'),'hh24:mi:ss')
          and t.policy_id=item.policy_id;
        if v_count>0 then
          :new.data_status:=0;
          exit;
        end if;
      elsif item.run_mode=2 then --模式3，检查周和时段
        select count(*) into v_count from psp_tr_illegal_filterquantum t
        where to_date(t.begin_time,'hh24:mi:ss')<=to_date(to_char(:new.pass_time, 'hh24:mi:ss'),'hh24:mi:ss')
          and to_date(t.end_time,'hh24:mi:ss')>=to_date(to_char(:new.pass_time, 'hh24:mi:ss'),'hh24:mi:ss')
          and t.weekday=to_char(:new.pass_time-1,'d')
          and t.policy_id=item.policy_id;
        if v_count>0 then
          :new.data_status:=0;
          exit;
        end if;
      end if;
    end loop;
    --根据处理流程配置检查是否需求分拣审核
    begin
      select PROCESS into v_process from PSP_TR_ILLEGAL_SOURCE t where t.source_no=:new.DATA_RECORD_SOURCE;
    exception
     when NO_DATA_FOUND then
       v_process:=99;
    end;
    --检查上报点位
    begin
      select TOLLGATE_ID,TIME_QUANTUM into v_tollgateId,v_timeQuantum from psp_tr_reporttollgate
       where state='1'
         and TOLLGATE_ID=:new.tollgate_id
         and (DIRECTION is null or DIRECTION=:new.lane_direction or DIRECTION like '%' || :new.lane_direction || ',' || '%' or
             DIRECTION like '%' || ',' || :new.lane_direction || '%');
      if v_timeQuantum is null then
        v_process:=0;
      elsif v_timeQuantum is not null then
        select TOLLGATE_ID into v_tollgateId2 from psp_tr_rt_timequantum
        where TOLLGATE_ID = v_tollgateId
          and to_date(begin_time,'hh24:mi')<=to_date(to_char(:new.pass_time, 'hh24:mi'),'hh24:mi')
          and to_date(end_time,'hh24:mi')>=to_date(to_char(:new.pass_time, 'hh24:mi'),'hh24:mi');
        v_process:=0;
      end if;
    exception
     when NO_DATA_FOUND then
       v_process:=v_process;
    end;
    if v_process=0 and :new.pass_time>sysdate-15 then
      :new.sorting_flag:=99;
      :new.audit_flag:=99;
      :new.sorting_audit:=1;
    elsif v_process=2 then
      :new.sorting_flag:=1;
    end if;
    --针对数据来源为人工导入的数据特殊处理
    if :new.DATA_RECORD_SOURCE=5 then
      if v_process=1 then
        :new.sorting_flag:=0;
        :new.audit_flag:=0;
        :new.sorting_people:='';
        :new.auditor:='';
      elsif v_process=2 then
        :new.audit_flag:=0;
        :new.sorting_people:='';
        :new.auditor:='';
      end if;
    end if;
  end if;
end;
/

