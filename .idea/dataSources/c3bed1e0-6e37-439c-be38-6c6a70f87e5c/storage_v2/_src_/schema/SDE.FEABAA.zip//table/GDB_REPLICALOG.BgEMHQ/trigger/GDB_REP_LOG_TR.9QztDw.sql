create trigger GDB_REP_LOG_TR
    after insert or update or delete
    on GDB_REPLICALOG
DECLARE passed_table_name  VARCHAR2(32) := 'GDB_REPLICALOG'; BEGIN UPDATE GDB_TABLES_LAST_MODIFIED SET last_modified_count = last_modified_count + 1 WHERE table_name = passed_table_name; IF SQL%NOTFOUND THEN INSERT INTO GDB_TABLES_LAST_MODIFIED VALUES (passed_table_name, 1);END IF; END;
/

