create procedure proc_psmp_congest_internet as
begin
       update Psp_Tr_Primaryroad set congestion_level=-1 where update_time<sysdate-2/1440 and congestion_level not in(1,-1);
       update PSP_TR_SECONDARYROAD set congestion_level=-1 where update_time<sysdate-2/1440 and congestion_level not in(1,-1);
       update PSP_TR_ORDINARYROAD set congestion_level=-1 where update_time<sysdate-2/1440 and congestion_level not in(1,-1);
       update PSP_TR_SIMPLEROAD set congestion_level=-1 where update_time<sysdate-2/1440 and congestion_level not in(1,-1);
       commit;
end;
/

