create FUNCTION st_aggr_intersection (input SDE.st_geometry) return SDE.st_geometry AGGREGATE USING stgeom_aggr_intersection;
/

