create Type     st_multilinestring 
                                               
        under SDE.st_multicurve 
        --C_Type_Release 1001
(
  constructor Function st_multilinestring(geom_str clob,srid number) Return self AS result deterministic,
  static Function get_release Return number
);
/

