create view PSMP_VIEW_ILLEGAL as
select pass_time,tollgate_id,illegal_type from psp_tr_illegal_event
union all
select pass_time,tollgate_id,illegal_type from psp_tr_nonmotor_illegal
/

