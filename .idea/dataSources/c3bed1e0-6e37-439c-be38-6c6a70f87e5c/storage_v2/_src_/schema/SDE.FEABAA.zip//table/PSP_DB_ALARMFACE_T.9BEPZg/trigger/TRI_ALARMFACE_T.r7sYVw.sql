create trigger TRI_ALARMFACE_T
    after insert
    on PSP_DB_ALARMFACE_T
begin
  insert into psp_db_alarmface select a.alarm_id, a.picture_id, a.object_id, a.pass_time, a.alarm_time,
  case when b.tollgate_id is null
  then ' '
  else
    b.tollgate_id
   end,
  a.camera_server_name,a.file_uri, a.deal_state, a.deal_user, a.deal_time, a.deal_text, a.report_state, a.report_time ,
  case
  when b.camera_id   is   null
  then   ' '
   else
   b.camera_id
 end, a.score
  from psp_db_alarmface_t a
  left join psp_db_surfacecam b on a.camera_server_name = b.camera_server_name;

  delete from psp_db_alarmface_t;
end;


create or replace trigger tri_person_t
  after insert on sde.psp_db_person_t
begin
  insert into psp_db_person select a.object_id,
  case when b.tollgate_id is null
    then ' '
  else
    b.tollgate_id
  end,
  basic_id, info_kind, origin_picture_id, left_topx, left_topy, right_btmx, right_btmy,
  file_uri, has_bike, main_color, up_color, low_color, sex, age_range, wheels, has_glass,
  has_bag, has_handle, has_helmet, has_umbrella, angle_type, bike_color, bike_type, seating_count, pass_time,
  report_time
  from psp_db_person_t a
  left join psp_db_videostructure b on a.camera_server_name = b.camera_server_name;

  delete from psp_db_person_t;
end;
/

