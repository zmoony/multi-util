create Type     st_point 
                                              
        under SDE.st_geometry 
        --C_Type_Release 1001
(
  constructor Function st_point(geom_str varchar2,srid number) Return self AS result deterministic,
  constructor Function st_point(pt_x number,pt_y number,srid number) Return self AS result deterministic,
  constructor Function st_point(pt_x number,pt_y number,pt_z number,srid number) Return self AS result deterministic,
  constructor Function st_point(pt_x number,pt_y number,pt_z number,measure number,srid number) Return self AS result deterministic,
  static Function get_release Return number
) NOT final;
/

