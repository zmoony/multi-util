create procedure trIncidentJob as
  ROADCODE   VARCHAR(32);
  CROSSCODE  VARCHAR(32);
  CROSSNAME  VARCHAR(32);
  imgUrl     VARCHAR(64);
  intRadom   NUMBER;
  longitude  NUMBER(38, 8);
  latitude   NUMBER(38, 8);
  tollgateId VARCHAR(64);
  inciSubType VARCHAR(32);
  INCIDENT_TYPE NUMBER;
  people VARCHAR(32);
  conent VARCHAR(500);
  temp   VARCHAR(32);
BEGIN
 --生成1~3随机数
  select trunc(dbms_random.value(1, 4)) into intRadom from dual;
   ---生成事件renyuan
select decode(trunc(dbms_random.value(0,3)),0,'张易',1,'李梦',2,'王晋',3,'赵若因') into people from dual;

select decode(trunc(dbms_random.value(0,3)),0,'两辆小轿车相撞，有人员受伤',1,'电瓶车碰擦一辆小轿车，无人员伤亡',2,'大型车载运输车辆发生侧翻，司机受伤',3,'多车辆发生追尾，多人员受伤') into conent from dual;

  --生成随机图片
  select imgUrl
    INTO imgUrl
    from (select imgUrl
            from (select 'http://172.17.112.249/shijian1.jpg' imgUrl
                    from dual
                  union
                  select 'http://172.17.112.249/shijian2.jpg' imgUrl
                    from dual
                  union
                  select 'http://172.17.112.249/shijian3.jpg' imgUrl
                    from dual
                  union
                  select 'http://172.17.112.249/shijian.jpg' imgUrl from dual) T
           order by dbms_random.value)
   where rownum <= 1;

  ---随机事件类型
   select round(dbms_random.value(1,7)) into INCIDENT_TYPE from dual;
   select to_char(round(dbms_random.value(1,5))) into temp from dual;

   IF INCIDENT_TYPE = 1 
      THEN inciSubType := '10' || temp;
   ELSIF INCIDENT_TYPE = 4
      THEN inciSubType := '40' || temp;
   END IF;
   

  IF intRadom = 2 THEN
    --查询卡口Id
    select TOLLGATE_ID,longitude,latitude
  INTO tollgateId,longitude,latitude
  from (
      select * 
      from PSP_DB_TOLLGATE
      order by dbms_random.value)
  where rownum=1;
     
     --随机生成
      --inciSubType := 102;
  ELSE
    --随机路口路段
    --随机抽取10%的记录，随机查询1条记录
    select ROAD_CODE, CROSS_CODE, CROSS_NAME
  into ROADCODE, CROSSCODE, CROSSNAME
    from (
    select * 
    from psp_tr_crosscode
    order by dbms_random.value)
    where rownum=1;
     
      --随机生成
      --inciSubType := 103;
   select ROUND(dbms_random.value(118.717579,118.83834665),8) into longitude from dual;
   select ROUND(dbms_random.value(31.7748396,31.84553813),8) into latitude from dual;
    --select 0 into longitude from dual;
    --select 0 into latitude from dual;
  END IF;
  

  insert into PSP_TR_INCIDENT
    (PTI_ID,
     INCIDENT_SOURCE,
     TOLLGATE_ID,
     CREATE_TIME,
     INCIDENT_TYPE,
     INCIDENT_SUBTYPE,
     LANE_DIRECTION,
     INCIDENT_LEVEL,
     ROAD_CODE,
     CROSS_CODE,
     INCIDENT_PLACE,
     LONGITUDE,
     LATITUDE,
     ALARM_CONTENT,
     ALARM_PERSON,
     ALARM_TIME,
     CREATE_USER,
     HAS_ATTENTION,
     INCIDENT_STATE,
     VALID_FLAG,
     IMAGE_ONE,
     PASS_TIME,
     IMAGE_STORAGE)
  values
    (PSP_TR_INCIDENT_SEQ.Nextval,
     to_char(intRadom),
     tollgateId,
     sysdate,
     INCIDENT_TYPE,
     inciSubType,
     intRadom,
     1,
     ROADCODE,
     CROSSCODE,
     CROSSNAME,
     longitude,
     latitude,
     conent,
     people,
     sysdate,
     262,
     0,
     0,
     1,
     imgUrl,
     sysdate,
     '3');
  COMMIT;
END;
/

