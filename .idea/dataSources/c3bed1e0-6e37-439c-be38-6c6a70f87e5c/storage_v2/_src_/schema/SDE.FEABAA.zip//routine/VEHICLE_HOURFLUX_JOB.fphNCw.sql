create procedure vehicle_hourflux_JOB is
  ID  NUMBER;
  direction1  NUMBER;
  direction2  NUMBER;
  direction3  NUMBER;
  direction4  NUMBER;
  direction5  NUMBER;
  minute     NUMBER(2);
  LANE_NO NUMBER;
  VEHICLENUM1 NUMBER;
  VEHICLENUM2 NUMBER;
  VEHICLENUM3 NUMBER;
  VEHICLENUM4 NUMBER;
  VEHICLENUM5 NUMBER;
  TOLLGATE_ID1 VARCHAR(64);
  TOLLGATE_ID2 VARCHAR(64);
  TOLLGATE_ID3 VARCHAR(64);
  TOLLGATE_ID4 VARCHAR(64);
  TOLLGATE_ID5 VARCHAR(64);

BEGIN
--生成ID
  select  psp_ana_fsearchvehicle_seq.nextval into ID from dual;
  --生成1~4随机数
  select trunc(dbms_random.value(1,4)) into direction1 from dual;
  select trunc(dbms_random.value(1,4)) into direction2 from dual;
  select trunc(dbms_random.value(1,4)) into direction3 from dual;
  select trunc(dbms_random.value(1,4)) into direction4 from dual;
  select trunc(dbms_random.value(1,4)) into direction5 from dual;
  --分钟
  select time
    into minute
    from (select CASE
                   WHEN SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) < 5 THEN
                    to_number(SUBSTR(TO_CHAR(sysdate, 'mi'), 1, 1) || 0)
                   WHEN SUBSTR(TO_CHAR(sysdate, 'mi'), 2, 1) >= 5 THEN
                    to_number(SUBSTR(TO_CHAR(sysdate, 'mi'), 1, 1) || 5)
                 END AS time
            from dual);

  --车道编号
  select ROUND(dbms_random.value(1,4)) into LANE_NO from dual;
    --车流量
  select ROUND(dbms_random.value(630,2000)) into VEHICLENUM1 from dual;

  select ROUND(dbms_random.value(630,2000)) into VEHICLENUM2 from dual;

  select ROUND(dbms_random.value(630,2000)) into VEHICLENUM3 from dual;

  select ROUND(dbms_random.value(630,2000)) into VEHICLENUM4 from dual;

  select ROUND(dbms_random.value(630,2000)) into VEHICLENUM5 from dual;
  --卡口ID
    select TOLLGATE_ID
  INTO TOLLGATE_ID1
  from (
      select *
      from psp_vehicle_minuteflux
      order by dbms_random.value)
  where rownum=1;

      select TOLLGATE_ID
  INTO TOLLGATE_ID2
  from (
      select *
      from psp_vehicle_minuteflux
      order by dbms_random.value)
  where rownum=1;

      select TOLLGATE_ID
  INTO TOLLGATE_ID3
  from (
      select *
      from psp_vehicle_minuteflux
      order by dbms_random.value)
  where rownum=1;

      select TOLLGATE_ID
  INTO TOLLGATE_ID4
  from (
      select *
      from psp_vehicle_minuteflux
      order by dbms_random.value)
  where rownum=1;

      select TOLLGATE_ID
  INTO TOLLGATE_ID5
  from (
      select *
      from psp_vehicle_minuteflux
      order by dbms_random.value)
  where rownum=1;



insert into psp_vehicle_hourflux
  (ID,
   TOLLGATE_ID,
   DIRECTION,
   LANE_NO,
   SOURCE,
   YEAR,
   MONTH,
   DAY,
   HOUR,
   FSPACEOCCUPYRATION,
   FTIMEOCCUPYRATION,
   VEHICLENUM,
   CONGESTION,
   RKSJ,
   TJSJ)
values
  (psp_ana_fsearchvehicle_seq.nextval,
   TOLLGATE_ID1,
   direction1,
   LANE_NO,
   2,
   to_char(sysdate, 'yyyy'),
   to_char(sysdate, 'MM'),
   to_char(sysdate, 'DD'),
   to_char(sysdate, 'HH24'),
   0.000,
   0.000,
   VEHICLENUM1,
   null,
   sysdate,
   sysdate);

insert into psp_vehicle_hourflux
  (ID,
   TOLLGATE_ID,
   DIRECTION,
   LANE_NO,
   SOURCE,
   YEAR,
   MONTH,
   DAY,
   HOUR,

   FSPACEOCCUPYRATION,
   FTIMEOCCUPYRATION,
   VEHICLENUM,
   CONGESTION,
   RKSJ,
   TJSJ)
values
  (psp_ana_fsearchvehicle_seq.nextval,
   TOLLGATE_ID2,
   direction2,
   LANE_NO,
   2,
   to_char(sysdate, 'yyyy'),
   to_char(sysdate, 'MM'),
   to_char(sysdate, 'DD'),
   to_char(sysdate, 'HH24'),

   0.000,
   0.000,
   VEHICLENUM2,
   null,
   sysdate,
   sysdate);

   insert into psp_vehicle_hourflux
  (ID,
   TOLLGATE_ID,
   DIRECTION,
   LANE_NO,
   SOURCE,
   YEAR,
   MONTH,
   DAY,
   HOUR,

   FSPACEOCCUPYRATION,
   FTIMEOCCUPYRATION,
   VEHICLENUM,
   CONGESTION,
   RKSJ,
   TJSJ)
values
  (psp_ana_fsearchvehicle_seq.nextval,
   TOLLGATE_ID3,
   direction3,
   LANE_NO,
   2,
   to_char(sysdate, 'yyyy'),
   to_char(sysdate, 'MM'),
   to_char(sysdate, 'DD'),
   to_char(sysdate, 'HH24'),

   0.000,
   0.000,
   VEHICLENUM3,
   null,
   sysdate,
   sysdate);

   insert into psp_vehicle_hourflux
  (ID,
   TOLLGATE_ID,
   DIRECTION,
   LANE_NO,
   SOURCE,
   YEAR,
   MONTH,
   DAY,
   HOUR,

   FSPACEOCCUPYRATION,
   FTIMEOCCUPYRATION,
   VEHICLENUM,
   CONGESTION,
   RKSJ,
   TJSJ)
values
  (psp_ana_fsearchvehicle_seq.nextval,
   TOLLGATE_ID4,
   direction4,
   LANE_NO,
   2,
   to_char(sysdate, 'yyyy'),
   to_char(sysdate, 'MM'),
   to_char(sysdate, 'DD'),
   to_char(sysdate, 'HH24'),

   0.000,
   0.000,
   VEHICLENUM4,
   null,
   sysdate,
   sysdate);


   insert into psp_vehicle_hourflux
  (ID,
   TOLLGATE_ID,
   DIRECTION,
   LANE_NO,
   SOURCE,
   YEAR,
   MONTH,
   DAY,
   HOUR,

   FSPACEOCCUPYRATION,
   FTIMEOCCUPYRATION,
   VEHICLENUM,
   CONGESTION,
   RKSJ,
   TJSJ)
values
  (psp_ana_fsearchvehicle_seq.nextval,
   TOLLGATE_ID5,
   direction5,
   LANE_NO,
   2,
   to_char(sysdate, 'yyyy'),
   to_char(sysdate, 'MM'),
   to_char(sysdate, 'DD'),
   to_char(sysdate, 'HH24'),

   0.000,
   0.000,
   VEHICLENUM5,
   null,
   sysdate,
   sysdate);

  COMMIT;
END;
/

