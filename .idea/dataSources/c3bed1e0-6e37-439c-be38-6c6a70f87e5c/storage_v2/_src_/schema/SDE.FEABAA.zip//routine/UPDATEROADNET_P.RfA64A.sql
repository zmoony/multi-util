create procedure updateRoadNet_p is --但路网数据更新停滞时定时更新路网拥堵等级
begin
  update PSP_TR_ORDINARYROAD set congestion_level=-1 where (sysdate-update_time)*24*60>=30;
  update PSP_TR_PRIMARYROAD set congestion_level=-1 where (sysdate-update_time)*24*60>=30;
  update PSP_TR_SECONDARYROAD set congestion_level=-1 where (sysdate-update_time)*24*60>=30;
  update PSP_TR_SIMPLEROAD set congestion_level=-1 where (sysdate-update_time)*24*60>=30;
end;
/

