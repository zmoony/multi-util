create Type st_mpointfromtext 
                                                 
          under st_point
        --C_Type_Release 1001
(
  constructor Function st_mpointfromtext(geom_str varchar2,srid number) Return self AS result deterministic,
  static Function get_release Return number
);
/

