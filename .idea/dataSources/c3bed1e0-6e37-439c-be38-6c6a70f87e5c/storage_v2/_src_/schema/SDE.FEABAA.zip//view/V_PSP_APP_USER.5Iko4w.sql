create view V_PSP_APP_USER as
select u.USER_ID,
       u.USER_GROUP_ID,
       u.USER_NAME,
       u.PASSWORD,
       u.USER_KIND,
       u.USER_LEVEL,
       u.IP_LIMIT,
       u.MUTIL_LIMIT,
       u.REAL_NAME,
       u.USER_TEL,
       u.REMARK,
       u.USBKEY_ID,
       u.IS_USBKEYLOGIN,
       u.IS_PASSWORDLOGIN,
       u.policeman_no,
       listagg(ur.role_id, ',') WITHIN
 group(
 order by ur.role_id) role_ids
  from psp_app_user u
  left join psp_app_userrole ur on ur.user_id = u.user_id
 group by u.user_id,
          u.user_group_id,
          u.user_name,
          u.password,
          u.user_kind,
          u.user_level,
          u.ip_limit,
          u.mutil_limit,
          u.real_name,
          u.user_tel,
          u.remark,
          u.usbkey_id,
          u.is_usbkeylogin,
          u.is_passwordlogin,
          u.policeman_no
/

