create FUNCTION FUNC_PPMC(P_NAME IN VARCHAR2,
                                     P_STR  IN VARCHAR2,
                                     P_MARK IN VARCHAR2,
                                     P_LOGIC IN VARCHAR2) RETURN VARCHAR2 AS
  --匹配名称,P_NAME待匹配名称，P_STR需要匹配的字符串，P_MARK需要分隔的分隔符，P_LOGIC逻辑判断或/与=or/and
  V_RETURN VARCHAR2(1);
  V_TEMP int;
  Cursor match_filter_cursor is
    select column_value as str from TABLE(func_strsplit(P_STR, P_MARK));
BEGIN
  V_RETURN:=1;
  V_TEMP:=0;
  for item in match_filter_cursor loop
    if P_LOGIC='and' then
      if instr(upper(P_NAME),upper(item.str))<1 and instr(upper(func_getpy(P_NAME)),upper(item.str))<1 then
        V_RETURN:=0;
        exit;
      end if;
    elsif P_LOGIC='or' then
      if instr(upper(P_NAME),upper(item.str))>0 or instr(upper(func_getpy(P_NAME)),upper(item.str))>0 then
        V_TEMP:=1;
        exit;
      end if;
    end if;
  end loop;
  if P_LOGIC='or' and V_TEMP=0 then
    V_RETURN:=0;
  end if;
  RETURN V_RETURN;
END;
/

