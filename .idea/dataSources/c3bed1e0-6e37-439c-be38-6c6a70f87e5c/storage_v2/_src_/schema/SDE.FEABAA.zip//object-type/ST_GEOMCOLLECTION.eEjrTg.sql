create Type     st_geomcollection 
                                               
        under SDE.st_geometry 
        --C_Type_Release 1001
(
  constructor Function st_geomcollection(geom_str varchar2,srid number) Return self AS result deterministic,
  static Function get_release Return number
) NOT final;
/

