create type stgeom_aggr_intersection as object (current_geom sde.st_geometry, static function ODCIAggregateInitialize (sctx IN OUT stgeom_aggr_intersection) return number,member function ODCIAggregateIterate (self IN OUT stgeom_aggr_intersection, value IN sde.st_geometry) return number,member function ODCIAggregateTerminate (self IN stgeom_aggr_intersection, returngeom OUT sde.st_geometry, flags IN number) return number,member function ODCIAggregateMerge (self IN OUT stgeom_aggr_intersection, ctx2 IN stgeom_aggr_intersection)return number);
/

